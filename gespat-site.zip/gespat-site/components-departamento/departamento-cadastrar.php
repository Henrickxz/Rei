<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cadastrar Departamento</title>
    <link rel="stylesheet" href="../styles/invalidar.css">
  </head>
  <body>
    <div id="section-departamento-cadastrar" class="content-section">
      <h2>Cadastrar Departamento</h2>
      <p>+ Cadastre um novo departamento</p>
      <div class="form-content">
        <form>
          <div class="form-group-patrimonio">
            <label for="nome-departamento">Nome do Departamento</label>
            <input
              type="text"
              id="nome-departamento"
              name="nome-departamento"
              placeholder="Nome do departamento"
            />
          </div>
          <button type="submit" class="btn-patrimonio">Cadastrar</button>
        </form>
      </div>
    </div>
  </body>
</html>
