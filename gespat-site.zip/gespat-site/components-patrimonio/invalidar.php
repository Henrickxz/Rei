<?php
include '../conexao.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = $_POST["codigo"];
    
    $codigo = mysqli_real_escape_string($con, $codigo);

    
    if (!empty($codigo)) {
        $sql = "INSERT INTO invalidos (fk_cod_patrimonio) VALUES ('$codigo')";
        
        if (mysqli_query($con, $sql)) {
            $message = "Patrimônio invalidado com sucesso!";
        } else {
            $message = "Erro ao invalidar: " . mysqli_error($con) . " | SQL: " . $sql;
        }
    } else {
        $message = "O campo código não pode estar vazio.";
    }

    mysqli_close($con);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invalidar patrimônio</title>
    <link rel="stylesheet" href="../styles/invalidar.css">
    <style>
        .message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            width: 400px;
            text-align: center;
            border-radius: 10px;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 9999;
        }

        .message.error {
            background-color: #f2dede;
            border-color: #ebccd1;
            color: #a94442;
        }

        /* Botão para fechar o alerta */
        .close-btn {
            background: none;
            border: none;
            font-size: 18px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
            cursor: pointer;
            color: #333;
        }
    </style>
</head>
<body>

<div class="main-content-patrimonio">
    <!-- Invalidar Patrimônio -->
    <div id="section-invalidar" class="content-section">
        <h2>Invalidar</h2>
        <p>+ Invalide um patrimônio existente</p>
        <div class="form-content">

            <?php if (!empty($message)): ?>
                <div class="message <?php echo (strpos($message, 'Erro') !== false) ? 'error' : ''; ?>">
                    <?php echo $message; ?>
                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group-patrimonio">
                    <label for="codigo">Código</label>
                    <input type="number" id="codigo" name="codigo" placeholder="Código do patrimônio">
                </div>
                <button type="submit" class="btn-patrimonio">Invalidar</button>
            </form>

        </div>
    </div>
</div>

</body>
</html>
