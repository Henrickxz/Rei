<?php
include '../conexao.php';

$message = '';
$departamentos = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $codigo = $_POST["codigo"];
    $fabricante = $_POST["fabricante"];
    $cor = $_POST["cor"];
    $numero_serie = $_POST["numero-serie"];
    $descricao = $_POST["descricao"];
    $departamento = $_POST["departamento"];

    
    $codigo = mysqli_real_escape_string($con, $codigo);
    $fabricante = mysqli_real_escape_string($con, $fabricante);
    $cor = mysqli_real_escape_string($con, $cor);
    $numero_serie = mysqli_real_escape_string($con, $numero_serie);
    $descricao = mysqli_real_escape_string($con, $descricao);
    $departamento = mysqli_real_escape_string($con, $departamento);

  
    $sql = "INSERT INTO patrimonio (codigo, fabricante, cor, n_serie, descricao, fk_departamento_nome) 
            VALUES ('$codigo', '$fabricante', '$cor', '$numero_serie', '$descricao', '$departamento')";

    if (mysqli_query($con, $sql)) {
        $message = "Cadastro realizado com sucesso!";
    } else {
        $message = "Erro ao cadastrar: " . mysqli_error($con) . " | SQL: " . $sql;
    }


    $sql = "SELECT * FROM departamentos";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $departamentos = $result->fetch_all(MYSQLI_ASSOC);
    }

    
        mysqli_close($con);
    }
    ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar patrimônio</title>
    <link rel="stylesheet" href="../styles/cadastrar.css">
    <style>
        .message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            width: 400px;
            text-align: center;
            border-radius: 10px;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 9999;
        }

        .message.error {
            background-color: #f2dede;
            border-color: #ebccd1;
            color: #a94442;
        }

        /* Botão para fechar o alerta */
        .close-btn {
            background: none;
            border: none;
            font-size: 18px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
            cursor: pointer;
            color: #333;
        }
    </style>
</head>
<body>

<div class="main-content-patrimonio">
    <!-- Cadastrar Patrimônio -->
    <div id="section-cadastrar" class="content-section">
        <h2>Cadastrar</h2>
        <p>+ Cadastre um novo patrimônio</p>
        <div class="form-content">

        <?php if (!empty($message)): ?>
                <div class="message <?php echo (strpos($message, 'Erro') !== false) ? 'error' : ''; ?>">
                    <?php echo $message; ?>
                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group-patrimonio">
                    <label for="codigo">Código</label>
                    <input type="number" id="codigo" name="codigo" placeholder="Código do patrimônio">
                </div>
                <div class="form-group-patrimonio">
                    <label for="fabricante">Fabricante</label>
                    <input type="text" id="fabricante" name="fabricante" placeholder="Marca fabricante">
                </div>
                <div class="form-group-patrimonio">
                    <label for="cor">Cor</label>
                    <input type="text" id="cor" name="cor" placeholder="Cor do patrimônio">
                </div>
                <div class="form-group-patrimonio">
                    <label for="numero-serie">Número de série</label>
                    <input type="text" id="numero-serie" name="numero-serie" placeholder="Número">
                </div>
                <div class="form-group-patrimonio">
                    <label for="descricao">Descrição</label>
                    <textarea id="descricao" name="descricao" placeholder="Descrição do patrimônio"></textarea>
                </div>
                <div class="form-group-patrimonio">
                    <label for="departamento">Departamento</label>
                    <input id="departamento" name="departamento" placeholder="Nome do Departamento"></input>
                </div>
                <div class="image-placeholder-patrimonio">
                    <input type="image">
                </div>
                <button type="submit" class="btn-patrimonio">Cadastrar</button>
            </form>

        </div>
    </div>
</div>

</body>
</html>
