<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Consultar departamento</title>
    <link rel="stylesheet" href="../styles/consultar.css" />
  </head>
  <body>
    <div id="section-departamento-consultar" class="content-section">
      <h2>Consultar Departamento</h2>
      <p>+ Consulte um departamento existente</p>
      <div class="form-content">
        <form>
          <div class="form-group-patrimonio">
            <label for="nome-departamento-consultar"
              >Nome do Departamento</label
            >
            <input
              type="text"
              id="nome-departamento-consultar"
              name="nome-departamento-consultar"
              placeholder="Nome do departamento"
            />
          </div>
          <button type="submit" class="btn-patrimonio">Consultar</button>
        </form>
      </div>
    </div>
  </body>
</html>
