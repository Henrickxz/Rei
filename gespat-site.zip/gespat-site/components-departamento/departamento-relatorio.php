<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Relatório departamento</title>
    <link rel="stylesheet" href="../styles/invalidar.css">
  </head>
  </head>
  <body>
    <div id="section-departamento-relatorio" class="content-section">
      <h2>Gerar Relatório Departamento</h2>
      <p>+ Gere relatórios de departamentos cadastrados</p>
      <div class="form-content">
        <form>
          <div class="form-group-patrimonio">
            <label for="tipo-relatorio-departamento">Tipo de Relatório</label>
            <select
              id="tipo-relatorio-departamento"
              name="tipo-relatorio-departamento"
            >
            </select>
          </div>
          <button type="submit" class="btn-patrimonio">Gerar Relatório</button>
        </form>
      </div>
    </div>
  </body>
</html>
